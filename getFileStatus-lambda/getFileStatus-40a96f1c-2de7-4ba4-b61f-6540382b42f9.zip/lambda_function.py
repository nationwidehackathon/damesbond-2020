import boto3

def lambda_handler(event, context):
    print("In lambda handler")
    s3 = boto3.client('s3')
    queryparam=event['queryStringParameters']
    print(queryparam)
    fname=queryparam['fname']
    print(fname)
    response = s3.get_object(Bucket='damesbond-comprehend-output', Key=fname)
    emailcontent = response['Body'].read().decode('utf-8')

    resp = {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
        },
        "body": emailcontent
    }

    return resp