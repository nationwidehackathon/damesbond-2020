import boto3
import uuid
def lambda_handler(event, context):
    s3 = boto3.client("s3") 
    
    for record in event['Records']:
        sourceBucket = record['s3']['bucket']['name']
        sourceKey = record['s3']['object']['key']
       # sourceBucket = "damesbond-comprehend-source"
       # sourceKey = "textract_output.txt"
        destinationBucket = "damesbond-comprehend-output"
        destinationKey = 'negative-'+sourceKey
        
        positiveBucket = "sent.positive"
        postiveKey = 'normal-'+sourceKey
        
        copy_source = {
           'Bucket': sourceBucket,
           'Key': sourceKey
        }
        
        file = s3.get_object(Bucket = sourceBucket, Key = sourceKey)
        paragraph = str(file['Body'].read())
        print(len(paragraph))
        comprehend = boto3.client("comprehend")
        if(len(paragraph) >5000):
            n = 5000;
            out = [(paragraph[i:i+n]) for i in range(0, len(paragraph), n)]
            
            for text in out:
                print('^^^^^^^^^^^'+text)
                
                #Extracting sentiments using comprehend
                sentiment = comprehend.detect_sentiment(Text = text, LanguageCode = "en")['Sentiment']
                print(sentiment)
                
                if sentiment=='NEGATIVE':
                    s3.copy(copy_source, destinationBucket, destinationKey)
                    bucketName
                    print(' transferred to destination bucket')
                else:
                   s3.copy(copy_source, positiveBucket, postiveKey)
                   print(' transferred to regular bucket')  
        else:
             sentiment = comprehend.detect_sentiment(Text = paragraph, LanguageCode = "en")['Sentiment']
                #s3.upload_file(sourceKey, positiveBucket, sourceKey)
        s3r = boto3.resource('s3')
        object = s3r.Object(destinationBucket, sourceKey)
        object.put(Body=sentiment)

    return sentiment